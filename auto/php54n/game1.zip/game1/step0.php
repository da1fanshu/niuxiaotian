<?php
    //step0 游戏准备阶段
        global $Room;
        act('initroom',$msg,$connection);


