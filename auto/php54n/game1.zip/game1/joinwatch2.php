<?php
global $Room;


$id = $data2['room'];
$connection->user['is_start'] = 0;
$connection->user['is_watch'] = true;

$Room[$id]['gzlist'][$connection->user['id']] = array('nickname' => $connection->user['nickname'], 'id' => $connection->user['id'], 'img' => $connection->user['img']);

act('watchindex', $Room[$id]['index'], $connection);


act('watch', '', $connection);


$gzinfo['data'] = array_values($Room[$id]['gzlist']);



foreach ($Room[$id]['alluser'] as $connection3) {
$gzinfo['is_start'] = $connection3->user['is_start'];
$gzinfo['is_watch'] = $connection3->user['is_watch'];	
act('watchlist', $gzinfo, $connection3);
}	




act('operationButton', '', $connection);

act('initok', '', $connection);
act('initroom','',$connection);



if(!$Room[$id]['user'][$connection->user['id']]){ //如果进入玩家组了
$msg=$connection->user['index'];
$Room[$id]['index'][]=$connection->user['index']; //把位置让出来
unset($Room[$id]['user'][$connection->user['id']]); //删除玩家列表
$Room[$id]['index'] = array_flip(array_flip($Room[$id]['index']));
sort($Room[$id]['index']);
}





foreach ($Room[$id]['user'] as $connection3) { // 玩家组
    if ($connection3->user['online'] == '-1' && $Room[$id]['xx']['zt'] < 2) {
        $Room[$id]['user'][$connection3->user['id']]->user['zt'] = 0;
    } 
    $msg = array();
    $msg = array();
    $msg['user']['id'] = $connection3->user['id'];
    $msg['user']['nickname'] = $connection3->user['nickname'];
    $msg['user']['img'] = $connection3->user['img'];
    $msg['user']['index'] = $connection3->user['index'];
    $msg['user']['dqjf'] = $connection3->user['dqjf'];
    $msg['user']['online'] = $connection3->user['online'];
    $msg['user']['zt'] = $connection3->user['zt'];
    $msg['zt'] = $connection3->user['zt']; 
    act('adduser', $msg, $connection);
} 
